console.log('Hi I am connected');

//utitlity function
// 1. utility function to get DOM element from string
// any string you give it will return a dom element
function getElementFromString(string){
    let div = document.createElement('div');
    div.innerHTML = string;
    return div.firstElementChild;
}

//initialize number of parameters
let addedParamsCount = 0;

//hide parameter box initially
let parameterBox = document.getElementById('parameterBox');
parameterBox.style.display = 'none';

//if user clicks on json box hide param box else display params box
let paramRadio = document.getElementById('radioParameter');
paramRadio.addEventListener('click', () => {
    document.getElementById('requestJsonBox').style.display = 'none';
    parameterBox.style.display = 'block';
})
let jsonRadio = document.getElementById('jsonRadio');
jsonRadio.addEventListener('click', () => {
    parameterBox.style.display = 'none';
    document.getElementById('requestJsonBox').style.display = 'block';
})


//adding more parameters one click of +
let addParam = document.getElementById('addParam');
addParam.addEventListener('click', () => {
    let params = document.getElementById('params');
    let str = `
            <div id="parameterBox" class='my-3'>
                <div class="form-row">
                    <label for="url" class="col-sm-2 col-form-label">Parameter ${addedParamsCount+2}</label>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="parameterKey${addedParamsCount+2}" placeholder="Enter Parameter ${addedParamsCount+2} Key">
                    </div>
                    <div class="col-md-4">
                        <input type="text" class="form-control" id="parameterValue${addedParamsCount+2}" placeholder="Enter Parameter ${addedParamsCount+2} Value">
                    </div>
                    <button class="btn btn-primary removeParam">-</button>
                </div>
            </div>
    `;
    //convert string to dom element
    let paramElement =getElementFromString(str);
    // console.log(paramElement);
    params.appendChild(paramElement);

    //add event listener to remove element on click of -
    let removeParam = document.getElementsByClassName('removeParam');
    for (item of removeParam) {
        item.addEventListener('click',(e)=>{
            //e.targetthe one that is selected
            //parent element is the div that is added
            // IF YOU WANT YOU CAN ADD CONFIRMATION BOX
            e.target.parentElement.remove();
        })
    }

    // 50:15:03 
    addedParamsCount++;

})

// if the user clicks on submit button
let submit = document.getElementById('submit');
submit.addEventListener('click',()=>{
    
    // show please wait in the request box to requesr user to patience
    // document.getElementById('responseJsonText').value = 'Please Wait Fetching Response...';
    document.getElementById('responsePrism').value = 'Please Wait Fetching Response...';
    Prism.highlightAll();     

    
    let url = document.getElementById('url').value;
    let requestType = document.querySelector("input[name='requestType']:checked").value;
    let contentType = document.querySelector("input[name='contentType']:checked").value;
    //check values are getting are not or log all the values in debugging
    // console.log('url',url);
    // console.log('requestType',requestType);
    // console.log('contentType',contentType);

    // if user used params option instead of json collect it and put it in object
    if(contentType=='params'){
        data = {}; // ==> making null object

        for (let i = 0; i < addedParamsCount+1; i++) {
            if(document.getElementById('parameterKey'+(i+1))!=undefined){
            let key =  document.getElementById('parameterKey'+(i+1)).value;
            let value =  document.getElementById('parameterValue'+(i+1)).value;
            data[key] = value;
            }
        }
        data = JSON.stringify(data);
    }
    else{
        data = document.getElementById('requestJsonText').value;
    }

    //check values are getting are not or log all the values in debugging
    console.log('url',url);
    console.log('requestType',requestType);
    console.log('contentType',contentType);
    console.log('data',data);

// if the request type is post, invoke fetch api to create a oost request
    if (requestType == 'GET') {
        fetch(url,{
            method:'GET',
        })
        .then(response=>response.text())
        .then((text) => {
        // document.getElementById('responseJsonText').value=text;    
        document.getElementById('responsePrism').innerHTML=text;    
        Prism.highlightAll();     
        }); // ==> fetch end 
    }
    //post request help: https://jsonplaceholder.typicode.com/guide/
    else{
        fetch(url,{
            method: 'POST',
            body: data,
            headers: {
                'Content-type': 'application/json; charset=UTF-8',
              }
        })
        .then(response=>response.text())
        .then((text) => {
        // document.getElementById('responseJsonText').value=text; 
        document.getElementById('responsePrism').innerHTML=text;
        Prism.highlightAll();     
        });
    }
})