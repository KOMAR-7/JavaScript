# JavaScript
Here's the place to learn JavaScript.
There is a folder named JavaScript.
This folder contains 3 files:
1.html file.
2.Javascript folder with js files per tutorial wise
==> each file is written tutorial wise{
    1. first open html file on web and code in your favourite ide.
    2. each script is commented and description of each script is written on above the script, uncomment the script and open console
    3. each function of JavaScript is explainned in its own file above the use with the help of comment.
for eg. If I want to learn Windows Object in Javascript, I'll go below the html file(in code) and uncomment the script below the windows object comment.
        Then I'll open the file with the help of script number that I commented from the js_file in any of the ide. you feel comfortable.
}

let important = {
	note:  "Try to understand the topic, find errors and solve it",
	desc: "Comments are descriptive about the topic",
	start : function (){
	console.log('I am going to start now');
	}
}
important.start();

// Comments are descriptive about the topic.
I'll be uploading more files in the comming future

document.write('By Khan Omar')