console.log('Form JS');
const name = document.getElementById('name');
const email = document.getElementById('email');
const number = document.getElementById('number');
// console.log(name, email, number);
let validName = false;
let validNumber = false;
let validEmail = false;
$("#failure").hide(); // methods of bootstraph
$("#success").hide();
name.addEventListener('blur', () => {
    console.log('Name is blurred(clicked outside)');
    let regex = /^[a-zA-Z]([\sa-zA-Z0-9]){2,15}$/
    let str = name.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log('Name is Valid');
        name.classList.remove('is-invalid')
        validName = true;
    }
    else {
        console.log('Name is not Valid');
        name.classList.add('is-invalid');
        validName = false;
    }
})

email.addEventListener('blur', () => {
    console.log('Email is blurred(clicked outside)');
    let regex = /^([a-z0-9_\-\.]+)@([a-z0-9_\-\.]+)\.([a-zA-Z]){2,7}$/
    let str = email.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log('Email is Valid');
        email.classList.remove('is-invalid')
        validEmail = true;
    }
    else {
        console.log('Email is not Valid');
        email.classList.add('is-invalid');
        validEmail = false;
    }
})

number.addEventListener('blur', () => {
    console.log('Number is blurred(clicked outside)');
    let regex = /^([0-9]){10}$/
    let str = number.value;
    console.log(regex, str);
    if (regex.test(str)) {
        console.log('Number is Valid');
        number.classList.remove('is-invalid')
        validNumber = true;
    }
    else {
        console.log('Number is not Valid');
        number.classList.add('is-invalid');
        validNumber = false;
    }
})

let submit = document.getElementById('submit');
submit.addEventListener('click', (e) => {
    console.log('Submitted');
    //submit your form
    if (validEmail && validName && validNumber) {
        let failure = document.getElementById('failure');
        console.log('Everything is valid');
        let success = document.getElementById('success');
        success.classList.add('show');
        // failure.classList.remove('show');
        // $("#failure").alert('close');
        $("#failure").hide();
        $("#success").show();
    }
    else {
        console.log('Something is not valid. Having problem in submitting');
        let failure = document.getElementById('failure');
        failure.classList.add('show');
        // success.classList.remove('show');
        // $("#success").alert('hide');
        $("#success").hide();
        $("#failure").show();
    }
    e.preventDefault();
})