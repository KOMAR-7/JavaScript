console.log('CV Screener');
// data is an array of object which contains info. about the candidates 
const data = [
    {
        name: 'Madi',
        age: 17,
        city: 'Mumbai',
        language: 'Python',
        framework: 'Django',
        image: 'https://randomuser.me/api/portraits/women/75.jpg'
    },
    {
        name: 'Neuro',
        age: 16,
        city: 'Mumbai',
        language: 'JavaScript',
        framework: 'Angular',
        image: 'https://randomuser.me/api/portraits/women/76.jpg'
    },
    {
        name: 'Weed',
        age: 15,
        city: 'Banglore',
        language: 'Python',
        framework: 'Flask',
        image: 'https://randomuser.me/api/portraits/women/77.jpg'
    },
    {
        name: 'Bacchu',
        age: 17,
        city: 'Mumbai',
        language: 'Go',
        framework: 'goFramework',
        image: 'https://randomuser.me/api/portraits/women/78.jpg'
    }
]

function cvIterator(profiles) {
    let nextIndex = 0;
    return {
        next: function () {
            return nextIndex < profiles.length ?
                {
                    value: profiles[nextIndex++],
                    done: false
                } :
                { done: true }
        }
    };
}
const candidates = cvIterator(data);

// button listener
const next = document.getElementById('next');
next.addEventListener('click', nextCV);
nextCV();
function nextCV() {
    const currentCandidate = candidates.next().value;
    
    let image = document.getElementById('image');
    let profile = document.getElementById('profile');
    if(currentCandidate!=undefined){
    image.innerHTML = `<img src='${currentCandidate.image}'>`;
    profile.innerHTML = `<ul class="list-group">
  <li class="list-group-item">Name: ${currentCandidate.name}</li>
  <li class="list-group-item">Age: ${currentCandidate.age}</li>
  <li class="list-group-item">City: ${currentCandidate.city}</li>
  <li class="list-group-item">Language: ${currentCandidate.language}</li>
  <li class="list-group-item">Framework: ${currentCandidate.framework}</li>
</ul>`
}
else{
    alert('End of CV');
    window.location.reload();
}
}