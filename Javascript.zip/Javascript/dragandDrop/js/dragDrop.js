console.log('Hi I am connected');

const imgBox = document.querySelector('.imgBox');
const whiteBoxes = document.getElementsByClassName('whiteBox');

// console.log(imgBox,whiteBoxes);

imgBox.addEventListener('dragstart', (e) => {
    // console.log('DragStart Has been triggered');
    //on darg make border blue by adding class hold which is defined in css
    e.target.className += ' hold';
    //remove the image after it is been dropped
    setTimeout(() => {
        e.target.className = ' hide';
        // console.log('i ran');
    }, 0);

})

imgBox.addEventListener('dragend', (e) => {
    // console.log('Dragend has been triggered');
    e.target.className = 'imgBox';// hide calls will be replaced with imgBox
    e.preventDefault();

})

for (let whiteBox of whiteBoxes) {

    whiteBox.addEventListener('dragover', (e) => {
        e.preventDefault(); // neccessary because it cannot drop so you need to prevent default behaviour
        // console.log('dragOver');

    });

    whiteBox.addEventListener('dragenter', (e) => {
        // console.log('dragEnter');
        e.target.className += ' dashed';

    });

    whiteBox.addEventListener('dragleave', (e) => {
        // console.log('dragLeave');
        e.target.className = 'whiteBox'
    });

    whiteBox.addEventListener('drop', (e) => {
        // console.log('drop');
        e.target.append(imgBox);
    });

}