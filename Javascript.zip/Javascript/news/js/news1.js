console.log('This is my news1 js file');
// 7c61060c4b564a718e0dded21057d015

//Initialize the news api parameters
let source = 'bbc-news';
let apiKey = '7c61060c4b564a718e0dded21057d015';
// grab news container
newsAccordian = document.getElementById('newsAccordion');

const xhr = new XMLHttpRequest();

// xhr.open('GET', `https://newsapi.org/v2/top-headlines?sources=${source}&apiKey=${apiKey}`, true);
xhr.open('GET', `https://newsapi.org/v2/top-headlines?country=in&apiKey=7c61060c4b564a718e0dded21057d015`, true);



xhr.onload = function () {
  if (this.status === 200) {
    // console.log(this.responseText);
    let json = JSON.parse(this.responseText);
    let articles = json.articles;
    let newsHtml = '';
    articles.forEach(function (element, index) {
      let news = `
        <div class="card">
            <div class="card-header" id="heading${index}">
                <h2 class="mb-0">
        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapse${index}" aria-expanded="false" aria-controls="collapse${index}">
                <p><b>Breaking news ${index + 1}</b>. ${element['title']}</p>
        </button>
                </h2>
        </div>
            <div id="collapse${index}" class="collapse" aria-labelledby="heading${index}" data-parent="#newsAccordion">
                <div class="card-body">
                <p>${element['description']}.<a href="${element['url']}" target="_blank">Read More</a></p>
                </div>
            </div>
        </div>
                    `;
      newsHtml += news;
    });
    newsAccordian.innerHTML = newsHtml;
    console.log(articles);
  }
  else {
    console.log('Some error occured');
  }
}

xhr.send();
// paster

srch = document.getElementById('srch');
srch.addEventListener('click', function (e) {
  // console.log('Button clicked');

  let valL = document.getElementById('srchTxt').value.toLowerCase();
  // console.log(val);
  let card = document.getElementsByClassName('card');
  Array.from(card).forEach(function (element) {
    let title = element.getElementsByTagName('h2')[0].innerText.toLowerCase();
    if (title.includes(valL)) {
      element.style.display = 'block';
    }
    else {
      element.style.display = 'none';
    }
  });
  
  e.preventDefault();
})

srch = document.getElementById('srchTxt');
srch.addEventListener('input', function (e) {
  // console.log('Button clicked');

  let valL = document.getElementById('srchTxt').value.toLowerCase();
  // console.log(val);
  let card = document.getElementsByClassName('card');
  Array.from(card).forEach(function (element) {
    let title = element.getElementsByTagName('h2')[0].innerText.toLowerCase();
    if (title.includes(valL)) {
      element.style.display = 'block';
    }
    else {
      element.style.display = 'none';
    }
    
  });
  e.preventDefault();
})