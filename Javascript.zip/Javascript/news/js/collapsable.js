// don't look into this.
console.log('HI');
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var des = this.nextElementSibling;
    if (des.style.display === "block") {
      des.style.display = "none";
    } else {
      des.style.display = "block";
    }
  });
}