console.log('AJAX');
/*
When you make website without using any libraries o framework it is known as Vanila Javascript
Pure JavaScript = Vanila JavaScript
1.AJAX stands for asynchronous JavaScript and XML
2.AJAX helps in fetching data asynchronouly without interfering with the existing page
3.NO page reload or refresh
4.MOdern websites use JSON instead or XML for transfer of data
5.Advantage:
  -No page reload or refresh
  -Better user experience
  -Saves network bandwidth(cz it does not bring whhole doc)
  -Very interactive
6.AJAX uses XMLHtppRequest Object(also called xhr) to achive this.
7.MOdern websites use JSON instead or XML for transfer of data
8.Data can be transfered in any format and protocol

*/


