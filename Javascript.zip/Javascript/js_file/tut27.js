console.log('Exercise');
/*
Create a class library and implement the following:
constructor must take a book list as argument
1.getBookList();
2.issueBook(bookname,user)
3. returnBook(bookname)
*/

class library{
    constructor(book1,book2,book3){
        this.book1 = book1;
        this.book2 = book2;
        this.book3 = book3;
        // let bookName =['HarryPoter','Sherlock','ShakeSphere']; 
    }
    getBookList(){
        return `${this.book1}, ${this.book2}, ${this.book3} is available`;
    }
    issueBook(bookName,user){
        if(bookName == this.book1 || bookName == this.book2 ||bookName == this.book3){
        return `${user} is taking ${bookName} book`;
        }
        else{
            return `Sorry ${user} we don't have ${bookName} book`
        }
    }
    returnBook (bookName){
        if(bookName == this.book1 || bookName == this.book2 ||bookName == this.book3){
            return `${bookName} book is returned to the library`;
            }
            else{
                return `Sorry this ${bookName} book is not from our library`
            }
        // return `${bookName} is recived`
    }
}
let Madi = new library('HarryPoter','Sherlock','ShakeSphere');
console.log(Madi.getBookList());
console.log(Madi.issueBook('Sherlock','Madi'));
console.log(Madi.issueBook('Hardy','Madi'));
console.log(Madi.returnBook('HarryPoter'));
console.log(Madi.returnBook('Hardy'));

// let bookName =['HarryPoter','Sherlock','ShakeSphere']; 
// console.log(bookName.toString());
console.log('==================');
