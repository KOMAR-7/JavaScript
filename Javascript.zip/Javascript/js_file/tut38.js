console.log(`Regualr Expression and it's Function`);

let reg = /Madi/; //this is regular expression literal in js
console.log(reg); // ==> /Madi/
console.log(reg.source); // ==> Madi (Inside Content)

//Functions to match regular Expression
// Smart Searching

/*
1) exec() This function will return an array for match or null for no match

*/
let str1 = 'Perfect is replaced with Madi'
console.log(reg.exec(str1)); //match and says it index
let reg2 = /Madi/g;
console.log(reg2.exec(str1));
console.log(reg2.exec(str1));

/*
g is the global flag
it will take first and then print
then will go on the next on printing next
if found then it will print else will say null
Ex.
let reg3 = /Madi/g;
let str2 = 'Madi is perfect.Perfect word should be replaced with Madi.'
console.log(reg3.exec(str2));
console.log(reg3.exec(str2));
console.log(reg3.exec(str2));
Output:
// ==> ['Madi', index: 0, input: 'Madi is perfect.Perfect word should be replaced with Madi.', groups: undefined]
// ==> ['Madi', index: 53, input: 'Madi is perfect.Perfect word should be replaced with Madi.', groups: undefined]
// ==> null

*/

let reg3 = /madi/i; // ==> for case insenstivity
let str3 = 'Madi is perfect.'
let result = reg3.exec(str3);
// if you are using methods of function if there is an error it will stop executing and throw an error therefore I have placed inside if  
if (result) {
    console.log(result);
    console.log(result);
    console.log(result.index);
    console.log(result.input);
}
/*
2) test()  ..returns true or false
// checks if the expression /exp./ is present inside the string
*/
console.log(reg3.test(str1));

/*
3) match() // ==> it will return an array of result or null
we put in a string
*/

// let result3 = reg3.match(str3); // ==>This is wrong syntax
let result3 = str3.match(reg3); // ==>This is right
console.log(result3);

/*
3) search() // ==> returns index o first match else -1
*/
let str4 = `Perfect name should be replaced with Madi`
// let str4 = `Perfect name should be replaced`
let result4 = str4.search(reg3);
console.log(result4);

/*
5) replace() // ==> Returns new replacement
if you set the global flag to expression only the fist match is given
else only first match will be replaced
*/
let result5 = str4.replace('Madi','Omar');
console.log(result5);

console.log('Exercise');
let regEx = /World/;
let strEx = `My Heart......,  No Hello World or world. Only Madi`;

let check1 = regEx.source;
console.log(check1);
let check2 = regEx.test(strEx);
console.log(check2);
let check3 = regEx.exec(strEx);
console.log(check3);
console.log(check3.input);
console.log(check3.index);
let check4 = strEx.match(regEx);
console.log(check4);
let check5 = strEx.search(regEx);
console.log(check5);
let check6 = strEx.replace('World','Madi');
console.log(check6);
regEx = /World/g;
let check = regEx.flags
console.log(check);
