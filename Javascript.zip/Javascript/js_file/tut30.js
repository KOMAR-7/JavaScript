console.log('CallBack Functions');
//pretend this is a response coming from server
// const student = [
//     {name:'Madi', subject:'Science'},
//     {name:'Omar',subject:'Programming'}
// ]

// /*
// function inside a function is call function
// */
// function enrollStudent(student1){
//     setTimeout(function (){
//         student.push(student1);
//         console.log('Student Enrolled');
//     }, 3000);
// }
// function getStudent(){
//     setTimeout(function (){
//         let str = '';
//         student.forEach(function (s){
//             str += `
//             <li>${s.name}</li>
//             `;
//         })
//         document.getElementById('students').innerHTML = str
//         console.log('Student have been fetched');
//     }, 1000);
// }
//sunny will be enrolled 3 sec after but this will not be printed
//bcz it was enrolled after printing
//if you would change the time it would enroll first then will print the enrolled name
// let newStudent = {name:'Neuro',subject:'Medical'}
// enrollStudent(newStudent);
// getStudent();

// WITHOUT CALLBACK END
//WITH CALLBACK STRAT

const student = [
    {name:'Madi', subject:'Science'},
    {name:'Omar',subject:'Programming'}
]

/*
function inside a function is call function
*/
function enrollStudent(student1,callback){
    setTimeout(function (){
        student.push(student1);
        console.log('Student Enrolled');
        callback();
    }, 3000);
}
function getStudent(){
    setTimeout(function (){
        let str = '';
        student.forEach(function (s){
            str += `
            <li>${s.name}</li>
            `;
        })
        document.getElementById('students').innerHTML = str
        console.log('Student have been fetched');
    }, 1000);
}
//sunny will be enrolled 3 sec after but this will not be printed
//bcz it was enrolled after printing
//if you would change the time it would enroll first then will print the enrolled name
let newStudent = {name:'Neuro',subject:'Medical'}
enrollStudent(newStudent,getStudent);
// getStudent();
/*
callback:YOu can add whatever Parameter you want
It means when you give a callback to a function it will execute it first and then will execute further
Syntax:

function name1(params,callback) {
    //code
    callback();
}
function name2(params) {
    // code
}
//function calling
name1(params,name2);

*/