console.log('Fetch Api');

let myBtn = document.getElementById('myBtn');
let contentF = document.getElementById('contentF');

//fetch retuns promise
function getData(){
    // console.log('getData Started');
    let url = 'Madi.txt';
    fetch(url).then((response)=>{
        // console.log('Inside first Then');
        return response.text();
    }).then((data)=>{
        // console.log('Inside Second Then');
        console.log(data);
    })
}
// console.log('Before Running getData');
getData();
// console.log('After Running getData');

/*
Syntax:
    fetch(url).then((response)=>{
        return response.text();
    }).then((data)=>{
    })
}

*/

function getGitData(){
    let url = 'https://api.github.com/users'
    fetch(url).then((response)=>{
        //   return response.text(); // ==>will return in text form
        return response.json(); // ==>will return in obj form
        // return response.text();
    }).then((data)=>{
        // console.log(JSON.parse(data)); // ==> if you are doing .text to get in obj form
        console.log(data); 
    })
}
getGitData();
/* Get request end*/

/* Post request start */

function postData(){
    url ='https://api.instantwebtools.net/v1/passenger';
    data = '{"name": "Madi134", "trips": 12234,"airline": 10323}';
    params = {
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body: data
    } 
    
    fetch(url,params).then((response)=>{
        return response.json();
    }).then((data)=>{
        console.log(data); 
    })
    // fetch(url,params).then(response => response.json()).then(data=> console.log(data));
}
postData();