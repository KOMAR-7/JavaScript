console.log('Math obj');

let x = 7;
let y = 5;
let z;
// z = Math.PI; // ==> 3.141592653589793
// z = Math.E; // ==> 2.718281828459045
// z = Math.round(3.4); // ==> 3
// z = Math.ceil(3.1); // ==> 4
// z = Math.floor(3.9); // ==> 3
// z = Math.abs(-5); // ==> 5
// z = Math.sqrt(64); // ==> 8
// z = Math.pow(4,2); // ==> 16 (4 raised to 2)
// z = Math.min(1,3,5,2,0,-2); // ==> -2
// z = Math.max(1,-39,2,0,89);// ==> 89

// z = Math.random(); // ==>genrates number from 0 to 1
// 0,1 // ==> the number that is generated is between 0 to 1 so
// a = (0,1) // ==> let a = 0,1 => thats the range 
// (if you want to make it 0 to 100, just multiply by 100)
// a100 = a*100
// (if you want to make it 10 to 100, add 10 for starting range and just multiply by 100 and -10 from 100)
// a10_100 = 10+a*(100-10);
// z = 100 * Math.random() // ==>shows value from 0 to 100
// z = 50 + (100-50) * Math.random(); // ==> generates from 50 to 100
// z = Math.floor(50 + (100-50) * Math.random()); // ==> generates from 50 to 100
// Formula For Generating Random Numbers
// formula_random = starting_range + (end_range - starting_range) * Math.random();
// Example
// let starting_range = 10;
// let end_range =20;
// let formula_random = starting_range + (end_range - starting_range) * Math.random();
// console.log(formula_random);
console.log(z);