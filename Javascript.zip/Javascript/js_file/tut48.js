console.log('Destructyring');
// Destructuring

let a,b;
[a,b]= [5,7];
console.log(a,b);
[a,b,c,d]=[1,2,3,4,5,6,7,8,9];
// this will create a confusion

// if you write with 3 dots the first will be assigned with values given
// Rest left will be given to specified variable given after dots
[a,b,c,...d]=[1,2,3,4,5,6,7,8,9];
console.log(a);
console.log(b);
console.log(c);
console.log(d);

({a,b,c}={a:10,b:20,c:30,d:40,e:50})
console.log(a,b,c);
console.log(d);

//Array Destructuring
const name = ['Madi','Omar','Neuro'];
[a,b,c] = name;
console.log(a,b,c);

//Object Destructuring
const perfect= {
    known: 'Madi',
    age: 17,
    nick: 'Oily',
    start: function(){console.log('Fuction started');}
}
let {known,age,nick,start} = perfect;
console.log(known,age,nick,start);
start();