console.log('Error Handling');

let a = 'Madi';
// if (a != undefined) {
//     console.log('a is not undefined');
// }
// else {
//     console.log('a is undefined');
// }

// if (a != undefined) {
//     throw new Error('a is not undefined');
  // Custom error by throw new error to stop execution of program
// }
// else {
//     console.log('a is undefined');
// }

try {
    console.log('Try me and my try members');
    Madi();
    console.log('Hello');

} catch (error) {
    console.log(`Bro something went wrong in try block, that's why i am executing. See error by printing error`);
    console.log(error);
    // console.log(error.name);
    // console.log(error.message);
}finally{
    console.log('I will to run weather try or catch block executes or not');
}