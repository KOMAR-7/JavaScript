console.log("Hello Madi");// this is to print on console
//***********Variables in JS)***********
// var, let, const
var name1= 'Madi';
console.log(name1);
// you can also create an unidefined variable(A varible having nothing)
var name2;
console.log(name1,name2);
// integer
var number = 05;
console.log(number);

//const and let increase code readability
/* once you used var you can overide it
ex.
var name1= 'Madi';
name1='Omar';
console.log(name1)
Output: Omar

but if you do const you can not change afterwards
if you don't want your variable to change you will use const
You cannot declare un undefined const it should have some value to it
ex.
const cn; uninitialized variable
*/

// ***LET***
/*
let is the block level scope
other is global scope(inside braces)
you can overite let variables
ex.
var name="Madi";
{
    let name="Omar";
    console.log(name);
}
    console.log(name);

Output:
Omar
Madi

*/ 
var n1="Madi";
{
    let n1="Omar";
    console.log("I am done by 'let' "+n1);
}
    console.log("I am done by 'var' " + n1);

// Coding convention
/*
1. camelCase
2. kebab-case
3. snake_case
4. PascalCase

camel case advantage is you don't need to press tab or shift for intellisense
ex.
document.gebi
on press of enter it will print
document.getElementById
 */