console.log('Sets');
//set is collection of unique values;

// initialize an empty set
const mySet = new Set();

//adding values to the set
console.log("before",mySet);

mySet.add('Madi');
mySet.add('Omar');
mySet.add('Omar');
//values will not be repeated in Set
// Shaadi mei khana at raha aur icecream ek hi milagi hahaha!!!
// set mei same value dobara nahi jaa sakti hai
mySet.add(true);
mySet.add(3.14);
mySet.add(3.14);
mySet.add({name:'neuro'});
console.log('After',mySet);

//else add with help of constructor

// let mySet1 = new Set(['Madi','Omar']);
// console.log(mySet1);

console.log(mySet.size);
console.log(mySet.has('Omar'));


console.log('Before set removal');
console.log(mySet.has(3.14));
mySet.delete(3.14)
console.log('After set removal');
console.log(mySet.has(3.14));
console.log('After',mySet);

for (let item of mySet) {
    console.log(item);
}

mySet.forEach(element => {
    console.log(element);
});

console.log(Array.from(mySet));