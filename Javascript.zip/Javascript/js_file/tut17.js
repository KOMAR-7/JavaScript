console.log('Events and events object');
let gets = document.getElementById('events_h4').addEventListener('click',function(e){
    // console.log('You have cliked the'+document.getElementById('events_h4'));
    console.log('You have cliked the heading');    
    // location.href='//myshopweb.netlify.app'
    console.log(e);
    console.log(e.target);
    console.log(e.target.parentNode);
    console.log(e.target.id);
    console.log(e.offsetX);
    console.log(e.offsety);
    console.log(e.clientX);// ==> how far you clicked from the client or the node
    console.log(e.clienty);
})
/*
let get1=document.getElementById('events_li_2').addEventListener('mousemove',function(f2){
    // console.log('Hovered');
    // document.body.style.backgroundColor='red';
    document.body.style.backgroundColor=`rgb(${f2.offsetX},${f2.offsetX},193)`;
    // let cr1 = document.createElement('li');
    // let cr_t = document.createTextNode('Hover kiya to agaye hum');
    // cr1.appendChild(cr_t);
    // let add_1 = document.getElementById('event_li_3');
    // add_1=add_1.children[1]
    // add_1.appendChild(cr1);
})
// console.log(gets);
*/
let get2 = document.getElementById('events_ul').addEventListener('mouseover',function(f3) {
this.innerHTML = 'hello Vro';    
})
// console.log(get2);
