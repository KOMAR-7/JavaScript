console.log('ES6 classes and inheritance');
// a class is a collection similar data consist of methods and variable
// class is a blueprint of an object]

class Employee {
    constructor(givenName, givenExperince,givenDivision){
        this.name = givenName,
        this.experince = givenExperince
        this.division = givenDivision
    }
    slogan(){
        return `I am ${this.name}. This hospital is best`
    }
    // you don't need an object to call static method
    static enter(you){
        return `${you} entered`
    }
}
let Madi = new Employee('Madi',2,'Doctor');
console.log(Madi);
console.log(Madi.slogan());
console.log(Employee.enter('Madi'));

// super refers to the parent class variable or method
// the parent class constructor can be calee by super
// you cannot use this in static because you can call static without creating an Object
// static member can be accesed any where with the class name
// Constructor is when you create object it automatically runs
class programmer extends Employee{
    constructor(givenName, givenExperince,givenDivision,language,gitHub){
        super(givenName, givenExperince,givenDivision);
        this.language = language;
        this.gitHub = gitHub;
    }
    favouriteLanguage(){
        if(this.language=='Python'){
            return 'Python';
        }
        else{
            return 'Javascript'
        }
    }
    static multiply(a,b){
        return a*b;
    }
}
let Omar = new programmer('Omar',2,'Web','Python','KOMAR-7');
console.log(Omar);
console.log(Omar.favouriteLanguage());
console.log(Omar.gitHub);
console.log(programmer.multiply(10,20));