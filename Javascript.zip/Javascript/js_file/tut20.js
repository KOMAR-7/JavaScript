console.log('Creating editable div');
/*
you have to create a dov and inject it into the page which contains a heading
Whenever someone clicks on the div, it should be converted into editable item.
Whenever user clciks away (blur) and save the note into the local storage
*/
// create element
let divElem = document.createElement('div');
let val = localStorage.getItem('text');
let text;
if (val==null) {
    text = document.createTextNode('This is my element to be editied');
}
else{
    text = document.createTextNode(val);
}
// write text to created element
divElem.appendChild(text);

// atrribute set
divElem.setAttribute('id','elem');
divElem.setAttribute('class','elem1');
divElem.setAttribute('style','border:2px solid black; width:154px; margin:34px;padding:23px;');

// grab the main container
let cont = document.querySelector('.container');
let first = document.getElementById('heading');

// insert the element before first element with id given
cont.insertBefore(divElem,first);

// add event listener to divElem
divElem.addEventListener('click',function(){
    let noOfTextArea = document.getElementsByClassName('textarea1').length;
    // console.log(noOfTextArea);
    if(noOfTextArea ==0){
    let html = elem.innerHTML;
    divElem.innerHTML = `<textarea class="textarea1" id="textarea">${html}</textarea>`;
    }
    // listen for the blur event on textarea on click out
    let textArea = document.getElementById('textarea')
    textArea.addEventListener('blur',function(){
        elem.innerHTML=textArea.value;
        localStorage.setItem('text',elem.innerHTML)
    });
})

/* .length and grabbing of text area was done because on clicking on the element it showed the text area
but the text inside was not changing on clicking inside the tag it changed into the text area tag
therefore  we took .lenght to calculate how many times it is clicked
if 0 then well change
*/

/*
first we create element and for inserting text
then we check the local storage if it is empty we give a default statement with the help createTextNode
get element by document.getElementsId()
and use insertBefore('where',what)
the on click on the element given it turns into text
then what we write is stored in the local storage with the help of localStorage.setItem
so once you edited it will be stored in local storage and then after reloading it will chaeck the first condition,
here it will find localstorage not empty so the value written in localStorage will be printed the created element

*/