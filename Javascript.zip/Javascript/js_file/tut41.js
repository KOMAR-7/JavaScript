console.log('ShortHand Charcters Classes(Reg.)');

let regex = /\wadi/; // ==> A Word character - _ or alaphabet or number
regex = /\w+adi/ // ==>one or more Word characters - _ or alaphabet or number
regex = /\Wadi/ // ==> Non word character const str1 = 'M adi is M adi';
regex = /\W+adi/ // ==> More than one Non word character const str1 = 'M adi is M adi';
regex = /\d999/ // ==> means one digit before or after digit const str1 = 'Madi is Madi 9999';
regex = /\d+999/ // ==> more than one digit
regex = /\D+999/ // ==>non digit const str1 = 'Madi is Madi Omar999';
regex = /\sis Madi/ // ==> match whitespace character
regex = /\s+is Madi/ // ==> match one or more than one whitespace character const str1 = 'Madi         is Madi';
regex = /\Sis Madi/ // ==> match non whitespace character const str1 = 'Madiis Madi';
regex = /\S+is Madi/ // ==> match one or more than one non whitespace character const str1 = 'Madi         is Madi';
regex = /Madi\b/ // ==> Word boundary kinda whitespace after particular word

//Assertion
regex = /M(?=)a/ // ==>M should be followed  by a
regex = /M(?!)y/ // ==>M should not be followed  by y

const str1 = 'Madi is Madi';
let result1 = regex.exec(str1);
console.log('The result from exec:', result1);

if (regex.test(str1)) {
    console.log(`The string '${str1}' matches the expression ${regex.source}`);
}
else {
    console.log(`The string '${str1}' does not matches the expression ${regex.source}`);
}