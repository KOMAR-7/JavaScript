console.log('Functions');
let name = 'Madi';
console.log(`How are you ${name}?, Hope you are sailing in a pink of health.`);
let name2='Omar';
console.log(`How are you ${name2}?, Hope you are sailing in a pink of health.`);
function ask(n,bye='Goodbye') {// ==>if user doesn't gives value so make in =
console.log(`How are you ${n}?, Hope you are sailing in a pink of health.${bye}`);
}
ask(name,'Tata');
ask(name2);
ask('Omar','Tata');
function ret(a){ 
    let msg=`${a}`; 
    return msg;
} 
let val = ret(98);// ==>return value assign to variable and use
console.log(val);
const diff_func= function(a){
        // console.log(`${a}`);
        return a;
}
let val1= diff_func('Hello');
console.log(val1 + ' Madi');
const obj={
    code:"Madistic",
    game:function(){
        return 'GTA'
    }
}
console.log(obj.game());
arr = ['Mango','Apple','Watermelon'];
arr.forEach(function(element,index) {
    console.log(element,index);
});
// Scope
var i = 200;
if(1){
   let i = 192; 
}
console.log('Global: '+ i);
function loc(){
    console.log('We are inside loc() function');
    var i = 9;
    console.log(i);
}
loc();
// let and const is block level scope