console.log(`Object literal,
Constructor,
Object Oriented
`);

// Object Literal for creating objects 
let car = {
    name: 'Maruti',
    top_speed: 120,
    run: function () {
        console.log('Car is running');
    }
}

// Constructor
// 1. new Date()
// this refers to current object variable (cz there might be many variable with same name)
// Constructor Defination: Initialize the object
// it creates many object as you want
// Here it creates generalCar Type object and we can create with the help of 'new' keyword
function generalCar(givenName,givenSpeed){
    this.name = givenName;
    this.topSpeed = givenSpeed;
    this.run = function(){
        console.log(`${this.name} is running`);
    }
    this.analyze = function (){
         console.log(`${this.name} car is slower by ${200 - this.topSpeed} Kmph than Mercedes`);
    }
}
car1 = new generalCar('Nissan',180)
car2 = new generalCar('Maruti Alto',160)
car3 = new generalCar('Mercedes',200)

// running constructor
running1 = car1.run();
console.log(running1);
analyzer = car2.analyze();
console.log(analyzer);
// console.log(car1,car2,car3);