// Loops
console.log('Loops');
/*
1.for
2.while
3.do-while
*/
console.log('For');
for(let i=0;i<10;i++){
    
    console.log(i);
}
console.log('While');
let j=10;
while (j>=0) {
    console.log(j);
    j--;
}
console.log('do-while');
let k=0;
do {
    if(k===5){
        k++;
        // break;
        continue;
    }
    console.log(k);
    k++;
} while (k<=10);
console.log('Array');
array=[11,23,44,65];
array.forEach(function(element,index,array) {
    console.log(element,index,array);
});
array.forEach(element => {
    console.log(element);
});

let obj={
    name:"Madi",
    age:17,
    type:"Perfect"
}
for(let key in obj){
    console.log(`The ${key} is ${obj[key]}`);
}