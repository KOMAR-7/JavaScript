console.log('Arrow Function');

//Regular Function
function Madi() {
    console.log('This is Madi');
}
Madi();

const Madi1 = function(){
    console.log('This is Madi1');
}
console.log(Madi1());

//Regular with return
const Madi2 = function(){
    return 'This is Madi2';
}
val = Madi2()
console.log(val);

//Arrow
const MadiA =()=>{
    return 'This is MadiA';
}
console.log(MadiA());

const MadiOne = () => {return 'This is MadiOne. Its a one liner'};
console.log(MadiOne());

const MadiWO = () => 'This is MadiWO.Its without braces';
console.log(MadiWO());

//Returning an obj
const MadiObj = ()=>({name:'Omar'});
console.log(MadiObj());

// No braces and no return required for one liners

const greet = (name)=> "Good Morning "+name;
console.log(greet('Madi'));

// if you have only one parameter you don't require braces for parameter
const greet1 = name1 => "Good Afternoon "+name1;
console.log(greet1('Madi'));

// For more than one parameter braces are reuired

const greet2 = (name2,msg) => "Good Morning "+name2 + "," + msg;
console.log(greet2('Madi','te quiero'));
