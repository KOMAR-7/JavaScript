// Data type (4)
// Javascript is dynamically typed language so you don't need to write what datatype it is. It will automatically detect type
/*
Two types:
1) Primitive Data Type
   Memory is stored in Stack
   -String: Sequnce of Character
   -Number: any number
   -Boolean: true and false
   -Null: Intentionally empty value
   -Undefined: default value as undefined(only declare)
   -Symbol: 

2) Refrence data type
   -Array
   -Object Literals
   -Functions
   -Date

*/

// -----Primitive Data Type:-----
// 1.String
var n1='Madi';
console.log("Hello "+ n1);
console.log("Datatype: "+ typeof(n1));

// 2.Number
var n2 = 7;
console.log("My number is: "+ n2);
console.log("Datatype: "+ typeof(n2));

// 3.Boolean
var truth=true;
console.log("My truth is: "+ truth);
console.log("Datatype: "+ typeof(truth));

// 4.Null: is a special value that represents an empty or unknown value.
var n3=null;
console.log(n3);
console.log("Datatype: "+ typeof(n3));

// 5.Undefined: Just declare or giving a variable value as not-defined
var n4;
// or
// var n4=undefined;
console.log(n4);
console.log("Datatype: "+ typeof(n4));

// Symbol left

// ------Refrence Data type------
// 1.Array
let myarr = [1,2,3,4,'Madi',true];
console.log(myarr);
console.log("Datatype: "+ typeof(myarr));

// 2.Object Literal: An object is a collection of properties (key:value)
let marks = {
    Omar: 89,
    Madi:82
}
console.log(marks);

// 3.Function
function My(){
    console.log("I am a function");
}
My();
console.log(typeof(My));

// 4.Date
let dt = new Date();
console.log("Datatype: "+ typeof(dt));