console.log('Date and Time');

let today = new Date();
console.log(today);
let otherDate = new Date('04-17-2004 04:30:21')
// month-date-year time
// otherDate = new Date('Apr 17 2004');
// otherDate = new Date('04/17/2004');
console.log(otherDate);
let getD = otherDate.getDate(); // ==> 17
getD = otherDate.getDay();
// ==> 6 (returns number of the day it occured)
// Sun  Mon Tues Wed Thur Fri Sat
//  0    1    2   3    4   5   6   
getD = otherDate.getFullYear();// ==> 2004
getD = otherDate.getMonth();// ==> 3 (it takes all month in numbers starting with 0)
getD = otherDate.getMinutes(); // ==> 30
getD = otherDate.getHours(); // ==> 4
getD = otherDate.getSeconds(); // ==> 21
getD = otherDate.getTime(); // ==> it's a time stamp (no of seconds from the date given)
console.log(getD);
// get ends
// set starts
otherDate.setDate(5);
otherDate.setFullYear(2005);
otherDate.setMonth(1); // ==> set with the help of indexing
otherDate.setHours(04);
otherDate.setMinutes(31);
otherDate.setSeconds(22);
console.log(otherDate);