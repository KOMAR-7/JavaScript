console.log('If-else');
const age=18;
if (age>18) {
    console.log('Baccha bada ho chuka!!!');
}
else if(age==18){
    console.log('Abhi ande se nikla hai');
}
else{
    console.log('Kiddo');
}
// *****************Greatest of 4 using nested if************
let a=1000 , b=9 , c=90, d=900;
if(a>b){
    if(a>c){
        if(a>d){
            console.log('a');
        }
        else{
            console.log('d');
        }
    }
    else{
        if(c>b){
            if(c>d){
                console.log('c');
            }
            else{
                console.log('d');
            }
        }    
        else{
            if(b>d){
                console.log('b');
            }
            else{
                console.log('d');
            }
        }
    }
    
    }
    else{
     if (b>c) {
        if(b>d){
            console.log('b');
        }
        else{
            console.log('d');
        }
     } else {
        if(c>d){
            console.log('c');
        }
        else{
            console.log('d');
        }
     }   
    }
    // ==>End HaHaHa!!!!
// && - and
if((a>b)&&(a>c)&&(a>d)){
    console.log('A bada hai **');
}
else if((b>a)&&(b>c)&&(b>d)){
    console.log('B bada hai **');
}
else if((c>a)&&(c>b)&&(c>d)){
    console.log('C bada hai **');
}
else if((d>a)&&(d>b)&&(d>c)){
    console.log('D bada hai **');
}
else{
    console.log('Something is matching');
}

// || - or
let fruit1=['Apple','Mango'];

if(fruit1.includes('Mango') || fruit1.includes('Sitafal')){
    console.log('Chalis');
}
else{
    console.log('Bhai na Mango Hai na Sitafal');
}

// Try(Tp)
let person1={
    Name: ['Madi','Omar','Neuro'],
    Age: [17,18,16],
    Gender:['Female','Male','Female'],
    color:['black','black','purple']
}
let name1='Neuro';
let i = person1['Name'].indexOf(name1);
// console.log(i);
// one way to get equal
// if(person1['Name'][i].toUpperCase==name1.toUpperCase){
if(person1['Name'][i]==name1){
    console.log('Hello ' + person1.Name[i]);
    if(person1.Gender[i]=='Male'){
        if(person1.Age[i]>=18){
            console.log('Kya baat hai baccha bada hogaya!!! 1st gate Number');
        }
        else{
            console.log('Get bigger and visit later Bye!!!');
        }
    }
    else{
        if(person1.Age[i]>=18){
            console.log('Kya baat hai bacchi bada hogaya!!! 2nd gate Number');
        }
        else{
            console.log('Get bigger and visit later Bye!!!');
        }   
    }
}    
// conditional operator or ternary operator(condition?true:false)
console.log((person1['Age'].includes(18)?'18 is included':'18 is not included'));

// *****Switch*****
let eq = 18;
let les = eq<18;
let mor = eq>18;
switch (eq) {
    case les:
        console.log('Bada hoja');
        break;
    case mor:
            console.log('Bada hogaya');
            break;
    case eq:
        console.log('Just bahar aaya');
        break;
    default:
        console.log('Wrong input');
        break;
} 