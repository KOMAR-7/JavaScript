console.log('Metacharacters');

let regex = /Madi/;
regex = /^Madi/; // ==> Starts with
regex = /Madi$/; // ==> Ends with
regex = /M.di/; // ==> if any one characters is replaced woth the dot it will accept it. let str1 = 'Mjdi is mhdi';
regex = /M*di/; // ==> if any one or zero charcters is replaced with * it would except.
regex = /Ma?dii?t/; // ==> character before the question mark is optional (Can be there or cannot be there) here t is written after ? then it is mandatory.
regex = /M\*adi/; // ==> if you want to match a * or meta charcter use \ (backslash)

// let str1 = 'Mdi is perfect. Perfect should be replaced with madi. Madi is a feeling. Atlast Madi is Madi';
let str1 = 'Madi is Madi';

let result1 = regex.exec(str1);
console.log('The result from exec:', result1);

if (regex.test(str1)) {
    console.log(`The string '${str1}' matches the expression ${regex.source}`);
}
else {
    console.log(`The string '${str1}' does not matches the expression ${regex.source}`);
}