// Data type conversion and type coercion
/*
Type conversion is similar to type coercion because they both convert values from one data type to another with one key difference — type coercion is implicit whereas type conversion can be either implicit or explicit.
*/
console.log('Data type conversion and type coercion');
console.log('Type Conversion Start');
let a=20;
console.log('Datatype: '+ typeof(a));
a=String(20);
console.log('Dataype: '+ typeof(a));

let dt = new Date();
console.log(dt);
console.log('Dataype: '+ typeof(dt));
dt=String(new Date());
console.log(dt);
console.log('Dataype: '+ typeof(dt));

let arr = [1,2,3,4];
console.log(arr.length); // ==>4
arr = String([1,2,3,4]);
console.log(arr.length); // ==>7

// toString is aslo used
let dt1 = new Date();
console.log(dt1.toString(dt1));
console.log(typeof dt1.toString(dt1)); // ==> string
// String Kinda end

let n1="786";
console.log("Datatype: "+ typeof(n1)); // ==> string
n1=Number(n1);
console.log("Datatype: "+ typeof(n1)); // ==> number
n1=Number("56gh8");
console.log(n1+" ,Datatype: "+ typeof(n1)); // ==> NaN(Not A Number), number
n1=Number(true);
console.log(n1+" ,Datatype: "+ typeof(n1)); // ==> 1, number (true will be 1 default behaviour)
n1=Number([1,2,3,4,5]);
console.log(n1+" ,Datatype: "+ typeof(n1)); // ==> NaN(Not A Number), number
// NUmber Kinda end

let n2 = "89.50";
console.log(n2, " Datatype: "+ typeof(n2)); // ==> string
n2 = Number("89.50");
console.log(n2, " Datatype: "+ typeof(n2)); // ==> 89.5 ' Datatype: number'
// it converts it into int roundsoff
n2 = parseInt("89.68");
console.log(n2, " Datatype: "+ typeof(n2)); // ==> 89 ' Datatype: number'
n2 = parseFloat("89.68");
console.log(n2, " Datatype: "+ typeof(n2)); // ==> 89 ' Datatype: number'
// toFixed(n) it will show only n decimals
let n3 = parseInt("89.6863");
console.log(n2.toFixed(3), " Datatype: "+ typeof(n2)); // ==> 89.680  Datatype: number
console.log('Type Conversion End');
// Type Conversion Complete
// Type Coersion
console.log('Type Coercion Start');
let t1="123";
let t2=26;
console.log(t1+t2); // ==>12326 it does convert a number into  a string and appends it to a string

console.log('Type Coercion End');