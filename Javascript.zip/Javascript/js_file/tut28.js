console.log('Asynchronous');
/*
Asynchronous code allows the program to be executed immediately where the synchronous code will block further execution of the remaining code until it finishes the current one
*/
/*
SYNCHRONOUS
document.write("Hi"); // First
    document.write("<br>");
  
    document.write("Madi") ;// Second
    document.write("<br>");
      
    document.write("How are you?"); // Third

Output:
Hi
Madi
How are you?
 */
/*
ASYNCHRONOUS
document.write("Hi");
    document.write("<br>");
  
    setTimeout(() => {
        document.write("Let us see what happens");
    }, 2000);
  
    document.write("<br>");
    document.write("End");
    document.write("<br>");

Output:
Hi
End
let us see what happens
*/
/*
with the help of example you might know the meaning of synchrounous and asynchrounous
Synchrounous: waits for the previous code to be executed
Asynchrounous: doesn't waits for the previous statement(synchronous code) to be executed 
               Asynchronous code allows the program to be executed immediately where the synchronous code will block further execution of the remaining code until it finishes the current one
               Functions running in parallel with other functions are called asynchronous
               it it similar like threading in Java
               Many asynchronous call can be done to complete a job


               1. any computation requires proceesor to do our javascripting.
               2. many request interact with things outside processor.
                  for ex they may communicate over a network or request data from the storage disk.
               3. This is a lot slower process than getting it from the memory.
               4. We don't want our procesor to sit idle whne such things are happening.
               "ye kaam to ho raha hai aagey ka kaam kartey hai.
               ye kaam bhi chal raha aur doosra do."
               5. An asynchronous model allows multiple things at the same time.
               6. A synchronous model things happen one at a time.   
*/
// for (let index = 0; index < 45; index++) {
//     const element = index;
//     console.log('This is index number'+index);   
// }
// console.log('Done printing');
//Done printing will be printed after completing for loop

// console.log('Hi');  
//     setTimeout(() => {
// console.log('Hello Timeout');
//     }, 2000);
  
// console.log('Hi written after timeout');
//     console.log("End");
setTimeout(() => {
    for (let index = 0; index < 45; index++) {
        const element = index;
        console.log('This is index number'+index);   
    }    
}, 1000);
console.log('Done printing');
// Done Printing will print then after 1sec for loop will be executed