console.log('Generators');

//generates value on call not storing it
//if you do this in array it will take more space so use genrators
// whenever i will call you then only generate it


function* numberGen() {
    let i = 0;
    // yield 1;
    // yield 2;
    // yield 3;
    while (true) {
        yield (i++);
        // yield (i++).toString();
    }
}

const gen = numberGen();
console.log(gen.next().value);
console.log(gen.next().value);
console.log(gen.next().value);
console.log(gen.next());
/*

Output:
it is for commented part cz the more you give yield the more it will genrate
{value: 1, done: false}
{value: 2, done: false}
{value: 3, done: false}
{value: undefined, done: true}
*/