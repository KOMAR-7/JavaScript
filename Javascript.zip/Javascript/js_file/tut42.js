console.log('Iterators');

function myIterator(values) {
    let nextIndex = 0;
    //function returning object
    return {
        next: function () {
            if (nextIndex < values.length) {
                return {
                    //in return an object is also returning a value cz it's a function
                    value: values[nextIndex++],
                    done: false
                }
            }
            else {
                return {
                    done: true
                }
            }
        }
    }
}

const valuesay = ['Madi', 'Omar', 'Neuro'];
console.log(valuesay);
const names = myIterator(valuesay);
console.log(names.next().value);
console.log(names.next().value);
console.log(names.next().value);
console.log(names.next().value);
