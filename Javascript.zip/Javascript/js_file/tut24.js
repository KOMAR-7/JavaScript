console.log('Object Prototypes');
// prototype: from where you started building
// making use for further use (or extension for simpler use)
let obj = {
    name: "Madi",
    stream: "Science",
    address: "Heart"
}
function Obj(givenName) {
    this.name = givenName;
}
let obj2 = new Obj('Omar');
// edit prototype
Obj.prototype.getName = function () {
    return this.name;
}
console.log(obj2.getName()); // ==> Omar
Obj.prototype.setName = function (newName) {
    this.name = newName;
}
Obj.prototype.todayDate = new Date;
console.log(obj2.todayDate); // ==> Omar

console.log(obj2.setName('Madi'));
console.log(obj2.getName()); // ==> Madi
console.log(obj2);