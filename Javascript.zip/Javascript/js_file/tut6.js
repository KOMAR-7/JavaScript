// String Methods and property
console.log('String Method');
let str1 = "Omar";
let str2 = " Madi";
console.log(str1+str2);
let str3 = str1.concat(str2);
console.log(str1.concat(str2));
console.log('.length : '+ str1.length);
console.log('.indexOf : '+ str1.indexOf('r'));// ==> 3 first occurance 
console.log('.charAt : ' + str1.charAt(2) );
console.log('.lastIndexOf : ' + str3.lastIndexOf('a'));
console.log('.endsWith : ' + str3.endsWith("Madi")); // ==> true
console.log('.includes : ' + str3.includes("Sasy")); // ==> false
console.log('.substring : ' + str3.substring(5,8));
console.log('.slice : ' + str3.slice(1,4));
console.log('.split : ' + str3.split(' '));// ==> whereever there is occurance it will split and insert comma and return in form of array 
console.log('.replace : '+ str3.replace('Madi','Sasu'));

// Template Literals
// if you want to add ' or " you should add front slash ' \
let fruit1 = '\'Apple\'';
let fruit2 = 'Mango'; 
// Use backtick ` instead of ' so you can wrute in multiple line without concatinating
let myhtml = `Hello ${str2}
            <h1>This is H1</h1>
            <p>Fruits are inserted with the help of $
            <br>
            Fruits you like are:
            <li>${fruit1}</li>
            <li>${fruit2}</li>
            </p>
            `;
document.body.innerHTML=myhtml;