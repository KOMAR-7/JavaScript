console.log('Local And session Storage');
/*
1.localStorage (permanent storage until removed manuaaly)
2.sessionStorage (temporary until tab is closed)
*/
let l_s1 = localStorage.setItem('Name1','Madi');
let l_s2 = localStorage.setItem('Name2','Omar');
localStorage.removeItem('Name');
// get and remove by key
let l_s3 = localStorage.getItem('Name2');
let arr = ['Madistic','Omarastic',82,89];
let l_s4 = localStorage.setItem('array',arr);
console.log(l_s3);
// localStorage.clear();
let arr_1 = localStorage.getItem('array');
console.log(localStorage.getItem('array'));
console.log(typeof arr_1);

// Since local storage will return an array as string
// so you need to typecast or can say use a function
let arr_2 = ['Madistic','Omarastic',82,89];
// to convert into string you use JSON.stringify(array_name)
let l_s5 = localStorage.setItem('array1',JSON.stringify(arr_2));
// To convert into array you use JSON.parse(array_name)
console.log(JSON.parse(localStorage.getItem('array1')));
console.log(typeof arr_2);

let arr_3 = ['Madi','Neuro','Omar'];
console.log(arr_3);
console.log(typeof arr_3);// ==>object
let stng5 = JSON.stringify(arr_3); 
console.log(stng5);
console.log(typeof stng5);// ==>string
console.log(stng5[1]);// ==> "
console.log(arr_3[1]);// ==> Neuro
let obj = {
    name:'Omar',
    type:'Mad',
    love:'Madi',
}
let loc = localStorage.setItem('book1',obj.name);
// Session Storage
let s_s1 = sessionStorage.setItem('Name1','Session1')
let s_s2 = sessionStorage.setItem('Name2','Session2')
let s_s3 = sessionStorage.setItem('Name3','Session3')
let s_s4 = sessionStorage.removeItem('Name1')
let s_s5 = sessionStorage.getItem('Name2');
console.log(s_s5);
// one more way
sessionStorage.test1 = "hello";
console.log(sessionStorage.test1);
console.log(sessionStorage["test1"]);