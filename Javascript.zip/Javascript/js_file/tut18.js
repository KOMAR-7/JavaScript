console.log('More on events');
let btn = document.getElementById('btn');
btn.addEventListener('click',funct1)
btn.addEventListener('dblclick',funct2)
btn.addEventListener('mousedown',funct3)
btn.addEventListener('mouseenter',funct4)
btn.addEventListener('mouseleave',funct5)
btn.addEventListener('mousemove',funct6)


function funct1(p1){
    console.log("thanks ", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}

function funct2(p1){
    console.log("thanks dblclick ", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}

function funct3(p1){
    console.log("thanks mousedown ", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}

function funct4(p1){
    console.log("mouseentered", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}

function funct5(p1){
    console.log("mouseleave ", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}

document.querySelector('.links').addEventListener('mousemove',function() {
    document.body.style.backgroundColor=`rgb(${f2.offsetX},${f2.offsetX},193)`;
})

function funct6(p1){
    console.log("mousemove ", p1);
    p1.preventDefault(); // ==> to prevent default behaivior notsubmit
}
// console.log(btn);