console.log('Arrays And Object');
let marks = [89,82];
const name1 = ['Omar',' Madi']; 
const arr1= [1,2,3,4,'Madi',3.14];
const arr2 = [1,2,['Sasy','Neuro']];
const arr3 = new Array(1,2,3,4,'Madi');

console.log('marks arr: ' + marks);
console.log('name arr: ' + name1);
console.log('arr1 arr: ' + arr1);
console.log('arr2 arr: ' + arr2);
console.log('arr3 arr: ' + arr3);

// property is length
console.log('Array (arr1) lenght: '+ arr1.length);
// methods is given by()
console.log('Array.isArray(array_name): ' + Array.isArray(arr1)); // ==> true arguments check and return boolean
arr1[0]= 'Omar';// ==> can update like this also
console.log('arr1 arr: ' + arr1);
// you can assign to variable also
let a = arr1[0];
console.log('Value of a:' + a);
console.log('.indexOf: '+ marks.indexOf(89));

// Mutating(Modifing array)
// ==>it will add to the last of the array
marks.push(89.2); 
console.log('Updated Marks Array: ' + marks);
// ==> shifts to the first one
marks.unshift(91); 
console.log('Updated Marks Array: ' + marks);
// ==> pop remove last element
marks.pop();
console.log('Updated Marks Array: ' + marks);
// ==> shifts() removes from first
marks.shift();
console.log('Updated Marks Array: ' + marks);
// ==> splice removes from the starting to n elements
arr2.splice(0,2);
console.log('.splice: ' + arr2);
// ==>concat
let marks1 = [91,87,85,89];
marks = marks.concat(marks1);
console.log('.concat: ' + marks);

// ******Object******
/* key: value */
let myobj={
    name: 'Madi',
    age: 17,
    color: 'black',
    marks: [98,98],
    'Street name': 'unknown'
}
console.log(myobj);
console.log('Age from obj: '+ myobj.age);
console.log('Without space written Key(also): ' + myobj['name']);
console.log('Space written key: ' + myobj['Street name']);