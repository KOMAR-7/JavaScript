console.log('Element Selector');
/*
ELement Selector:
1.single element selector
2.multi element selector
*/
let element=document.getElementById('first');
console.log(element);
console.log(element.className);
console.log(element.childNodes);
console.log(element.parentNode);
element.style.color='red';
element.innerText='Omar';
element.innerHTML='<h1>Madi<h1/>';

// Query selector
// ==> # is for accesing id (#idname)
let qs1=document.querySelector('#second');
console.log(qs1);
// ==> . is used for accessing class (.classname)
let qs2=document.querySelector('.container');
console.log(qs2);
// access by tag
let qs3=document.querySelector('h1');
console.log(qs3);
// one (single) element end

//*****Multi Element Selector*****
let m1=document.getElementsByClassName('container');
console.log(m1);
// ==> Chaning class inside a class
console.log(m1[0].getElementsByClassName('links'));
let m2 = document.getElementsByTagName('div');
console.log(m2);
Array.from(m2).forEach(element => {
    console.log(element);
});
// OR
for (let i = 0; i < m2.length; i++) {
    let x = m2[i];
    console.log(x);    
}
