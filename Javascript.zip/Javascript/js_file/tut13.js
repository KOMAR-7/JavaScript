console.log('Exercise');
let a=document.all
console.log(a);
// let al=document.links
// console.log(al);
// console.log(al.length);
// Array.from(al).forEach(element => {
//     let x = element.toString
//     if(x.includes('google')){
//    console.log(element);
//     }
// });

//  for (let i = 0; i < al.length; i++) {
//     if (al[i].contains('google')) {
//         console.log(al);
//     }    
//  }

let str1 = 'google';
let al=document.links
// let cnt=0
Array.from(al).forEach(element => {
    if(String(element).includes(str1)){
   console.log(element.href);
}
// else{
//      console.log(cnt);
// }
});
// console.log(al);