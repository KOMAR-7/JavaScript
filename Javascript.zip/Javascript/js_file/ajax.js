console.log('Ajax');
let fetchBtn = document.getElementById('fetchBtn');
fetchBtn.addEventListener('click', buttonClickHandler);

function buttonClickHandler() {
    console.log('fetchBtn clicked');
    // Initiate an xhr obj
    const xhr = new XMLHttpRequest();

    //Open the object
    xhr.open('GET', 'Madi.txt', true);
    // xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1',true);

    //use this for post request
    xhr.open('POST', 'https://dummy.restapiexample.com/api/v1/create', true);
    xhr.getResponseHeader('Content-type', 'json');


    // TAKE OR SEND === GET or POST request
    // Second where the data will come
    // if you want blocking(synchronous)request or non blocking(asynchronous) request
    // if asynchronous make third argument as trues

    //What to do on progress
    xhr.onprogress = function () {
        console.log('On Progress');
        //we show spinner
    }

    // what to do when response is ready
    xhr.onload = function () {
        //status code like 404 not found and many more
        if (this.status == 200) {
            console.log(this.responseText);
        }
        else {
            console.error('Some Error Occured');
        }
    }
    /*
    200 OK success status response code indicates that the request has succeeded.
    */
    /*
    0	UNSENT	            Client has been created. open() not called yet.
    1	OPENED	            open() has been called.
    2	HEADERS_RECEIVED	send() has been called, and headers and status are available.
    3	LOADING	            Downloading; responseText holds partial data.
    4	DONE	            The operation is complete.
    */
    // instead of using onload we use to use readystate
    xhr.onreadystatechange = function () {
        console.log('Ready State', xhr.readyState);
    }

    // send request
    // xhr.send();

    params = `{"Name":"Omar","Age":"18"}`;
    xhr.send(params);

    console.log('We are done');
}

let popbtn = document.getElementById('popBtn');
popbtn.addEventListener('click', popHandler);

function popHandler() {
    console.log('You have clicked the pop handler');

    const xhr = new XMLHttpRequest();

    //open the object
    xhr.open('GET', 'https://dummy.restapiexample.com/api/v1/employees', true);

    // what to do on respnse
    xhr.onload = function () {
        if (this.status === 200) {
            let obj = JSON.parse(this.responseText);
            console.log(obj);
            let list = document.getElementById('list');
            let str = "";
            for (key in obj) {
                str += `<li>${JSON.stringify(obj[key])}</li>`
                // str += `<li>${obj[key].employee_name}</li>`

            }
            // for (let i = 1; i < obj.length; i++) {
            //     str += obj[i].employee_name;
            // }
            list.innerHTML = str;
        }
        else {
            console.log('Some Error occured');
        }
    }
    xhr.send();
    console.log('We are done fetching employess');

}

// try
// let s = new Set('Omar','Madi');
// console.log(s);
// let s1 = new Set();
// s1.add('Omar');
// s1.add('Madi');
// console.log(s1);