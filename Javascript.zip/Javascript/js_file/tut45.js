console.log('Maps');
// Maps: we can use any type of key or value

const myMap = new Map();
console.log(myMap);

// const key1 = 'myStr', key2 = {}, key3 = function () { }
const key1 = 'myStr', key2 = {name:'Madi'}, key3 = function () {console.log('hello'); }


// instead of writing const again and again write in onw line with ,
myMap.set(key1, 'This is a string');
myMap.set(key2, 'This is a blank obj');
myMap.set(key3, 'This is a blank function');

console.log(myMap);

// getting the value from a Map
let value1 = myMap.get(key1);
let value2 = myMap.get(key2);
let value3 = myMap.get(key3);
console.log(value1);
console.log(value2);
console.log(value3);

console.log(myMap.size);

// You can loop using for of loop to get kyes and values
for (let [key, value] of myMap) {
    console.log(key, value);
}

// get only keys
for (let x  of myMap.keys()) {
    console.log(x);
}

// get values keys
for (let x  of myMap.values()) {
    console.log(x);
}

//using for each
myMap.forEach((value,key) => {
console.log('Key is',key);
console.log('Value is',value);    
});

// converting map to array
let myArr = Array.from(myMap);
console.log('Array of map',myArr);

// converting map to array
let myArrKey = Array.from(myMap.keys());
console.log('Array of map keys',myArrKey);

// converting map to array
let myArrValue = Array.from(myMap.values());
console.log('Array of map Values',myArrValue);
    