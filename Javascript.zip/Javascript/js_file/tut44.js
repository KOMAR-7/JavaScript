console.log('for of vs for in');

let people = ['Omar','Madi','Neuro'];
//1. Traditional for loop
for (let i = 0; i < people.length; i++) {
    const element = people[i];
    console.log(element);
}

//2.for in loop
const obj={
    name: 'Madi',
    language: 'Science',
    hobbies: 'Med'
}
console.log(obj);
for (let i = 0; i < Object.keys(obj).length; i++) {
    const element = obj[Object.keys(obj)[i]];
    console.log(element);   
}
for(let key in obj){
    console.log(obj[key]);
}

// loop through string
myStr = 'Madi is perfect';
for(let char in myStr){
    console.log(myStr[char]);
}

//3.for of loop
// if you do for in you will get index use for of to get string
// used for iterating
people = ['Omar','Madi','Neuro'];
for (let name of people) {
    console.log(name);
}
myStr = 'Madi is perfect';
for (const char of myStr) {
    console.log(myStr);
}