console.log('Creating,removing,replacing elements(Dom)');
let element1=document.createElement('li');
console.log(element1);
element1.className='createdclass';
element1.id='try1';
element1.setAttribute=('title','mytitle');
// element1.innerHTML='<b>Hello vro I am from DOM created</b>';
// OR
element1=document.createTextNode('I am form createTextNode')
let grab=document.querySelector('.container');
grab = grab.children[1];
grab.appendChild(element1);

let element2=document.createElement('h3');
element2.id = 'elem2'
element2.className ='e2';
let tnode= document.createTextNode('I am form element 2');
element2.appendChild(tnode);
element1.replaceWith(element2);

let myul = document.getElementById('bacche');
myul.replaceChild(element1,document.getElementById('first'));
myul.removeChild(document.getElementById('second'));


let element3=document.createElement('li');
console.log(element3);
element3.className='crealass';
element3.id='try2';
element3=document.createTextNode('I am form createTextNode element 3')


let pr0 = element2.getAttribute('class');
console.log(pr0);
let pr = element2.getAttribute('id');
console.log(pr);
let pr1 = element2.hasAttribute('id');
console.log(pr1);
pr2=element2.removeAttribute('id');
let pr3 = element2.hasAttribute('id');
console.log(pr3);
let pr4=element2.setAttribute('id','new_ele2');
let pr5 = element2.getAttribute('id');
console.log(pr5);
let pr6 = element2.hasAttribute('id');
console.log(pr6);

/* create an element with text as 'go to Madi' and create an tag outside
with href = shopwebapp.netlify.app*/
let exe1=document.createElement('a');
exe1.id='exe_li_3';
let exe_t= document.createTextNode('Madi');
exe1.appendChild(exe_t)
let access = document.querySelector('.exe1');
// console.log(exe1.hasAttribute('href'));
// console.log(access);// ==>div.exe1
console.log(access.childNodes[1]);// ==>li#exe_li_1
// console.log(access.children);
console.log(access.childNodes);
// access.childNodes[1].appendChild(exe1);
// console.log(exe1.hasAttribute('id'));
exe1.setAttribute('href','https://myshopweb.netlify.app/');
let put_li = document.createElement('li');
let put_li_t= document.createTextNode(exe1);
put_li.appendChild(exe1)
access.childNodes[1].appendChild(put_li);