console.log('Manipulating windows using js object');
// let a = window;
// console.log('Window Functions:');
// console.log(a);
// alert('Aur vro');
// let n1 = prompt("Type your name:");
// console.log('Hello '+n1);
// let c1=confirm('Are you sure you want ot delete');
// console.log(c1);// ==> Ok and cancel in alert tab
// let h1=innerHeight
// console.log(h1);
// let h2=outerHeight
// console.log(h2);
// let scx=scrollX;
// console.log(scx);
// let scy=scrollY;
// console.log(scy);

// let loc=location
// console.log(loc.toString());// ==> to get in string format

/*
if you want to go to any page using console.
1.Go on console
2. type
location.href = '//sitename.com'
location.href = '//google.com'
*/

// let h=history
// console.log(h);
/*
with history you can check how much you have travelled across page
history.lenght
history.go(-1) to go 1 back
*/