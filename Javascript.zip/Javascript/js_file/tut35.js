console.log('Async,Await');

function Madi() {
    return 'Madi';
}
let a = Madi();
console.log(a);

async function Madi1() {
    console.log('Inside Madi1');
    return 'Madi';
}

console.log('Before calling Madi1');
let a1 = Madi1();
console.log('After calling Madi1');
console.log(a);
console.log('Last line');

console.log('ASYNC + AWAIT');

async function Madi2() {
    console.log('Inside Madi2 function');
    const fget = 'https://api.github.com/users';
    const response = await fetch(fget)
    console.log('Before response');
    const users = await response.json();
    console.log('User resolved');
    return users;
}
console.log('Before calling Madi2');
let a2 = Madi2();
console.log('After Calling MAdi2');
console.log(a2);
a2.then(data => console.log(data));
console.log('Last line of js');

/*
aync will returt Promise
function inside console.log('');
it will see await and wait and will go outside
await means function go back when i'll complete i'll call you
On printing function, since it's a promise it will return  pending
when on doing (we use specially on resolving).then
then it will see the person which said await and will ask hua kya bhai!!!
then when it is completed it will go on next line
then when last await will appear it will see if there any other work left
if not it will wait for it to complet then will process further
asyn promise will be resolved on return
a.then will say whenever the promise is resolved go in then
when he sees await it will do rest of the work
*/