console.log('Website layout DOM');
a=document
// console.log(a);
// document.all gives all the html collection and will show all the attributes(tags) of html used
let col = document.all;
console.log(col);
// .nameofelement you can trigger to any html tag and view its collection
// let f=document.forms;
// console.log(f);
// Array.from(document.all).forEach(function(element) {
//     console.log(element);
// });// ==>will print all the tags
// you can get by index [num] 
// let l1=document.links[0].href
// console.log(l1);
// let sc=document.scripts
// console.log(sc);
// let im=document.images
// console.log(im)
