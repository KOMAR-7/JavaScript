console.log('Symbols');

// To Generate unique primitive
// Primitive Data types
const sys1 = Symbol('My Madi');
const sys2 = Symbol('My Madi');
console.log(sys1);
console.log(typeof sys1);
// each time a unique thing is made
// unique keys where difficult to make before es6 produce symbols
console.log(sys1===sys2); // ==> false

let a = 'Hi';
let b = 'Hi';
console.log(a==b);// ==> true

let k1 = Symbol('Identifiers for k1');
let k2 = Symbol('Identifiers for k2');


let myObj={};
myObj[k1]='Madi';
myObj[k2]='Omar';
myObj['nick']='Oily';
console.log(myObj);
console.log(myObj[k1]); // ==> Madi
console.log(myObj[k2]); // ==> Omar
console.log(myObj['nick']);

// symbols are ignored in for in loops
for (const key in myObj) {
console.log(key,myObj[key]);
}


// let myObj = {
//     k1:'Madi',
//     k2:'Omar'
// }
// console.log(myObj);