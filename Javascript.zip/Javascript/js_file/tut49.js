console.log('Clock');

let clock = document.getElementById('clock');
// console.log(clock);
function updateClock() {
    let currentTime = new Date()
    let currentHour = currentTime.getHours();
    let currentMinutes = currentTime.getMinutes();
    let currentSeconds = currentTime.getSeconds();

    // add zero if minutes and second are less than 10
    currentMinutes = (currentMinutes < 10 ? "0" : " ") + currentMinutes;
    currentSeconds = (currentSeconds < 10 ? "0" : " ") + currentSeconds;
    // to make 13 as 1
    currentHour = (currentHour > 12 ? currentHour - 12 : currentHour);
    currentHour = (currentHour == 0 ? 12 : currentHour);

    // appendning am pm if hor is greater than 12 than PM else AM
    let dayNight = (currentHour > 12) ? 'AM' : 'PM'
    let currentTimeStr = currentHour + " : " + currentMinutes + " : " + currentSeconds + " " + dayNight;
    clock.innerHTML = currentTimeStr
}

setInterval(() => {
    updateClock();
}, 1000);