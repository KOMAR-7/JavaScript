console.log('Promises');
/*
Promises are of 3 types:
-resolve
-reject
-pending

We use as a substitute of callback function
*/
function func1(){
    return new Promise(function(resolve,reject){
        setTimeout(() => {
            const error = true;
            // const error = false;
            
            if (!error) {
                console.log('Your promise has been resolved');
                resolve();
            }
            else{
                console.log('Your promise has not been resolved');
                reject('Sorry');
            }

            //mostly used when you do request to network make xhr request etc
        }, 2000);
    })
}

func1().then(function(){
    console.log('Madi:Thanks for resolvving');
}).catch(function(error){
    console.log('Very bad vro '+error)})

// function_name.then(if resolved).catch(if rejected);

//converting callback into promisses
const student = [
    {name:'Madi', subject:'Science'},
    {name:'Omar',subject:'Programming'}
]

/*
function inside a function is call function
*/
function enrollStudent(student1){
    return new Promise(function(resolve,reject){
        setTimeout(function (){
            student.push(student1);
            console.log('Student Enrolled');
            // let error =true;
            let error = false;
                if(!error){
                    resolve();
                }
                else{
                    reject();
                }
            }, 3000);
    })
}
function getStudent(){
    setTimeout(function (){
        let str = '';
        student.forEach(function (s){
            str += `
            <li>${s.name}</li>
            `;
        })
        document.getElementById('students').innerHTML = str
        console.log('Student have been fetched');
    }, 1000);
}
//sunny will be enrolled 3 sec after but this will not be printed
//bcz it was enrolled after printing
//if you would change the time it would enroll first then will print the enrolled name
let newStudent = {name:'Neuro',subject:'Medical'};
// enrollStudent().then(function(){getStudent()}).catch(function(){console.log('Error')});
// getStudent();
enrollStudent(newStudent).then(getStudent).catch(function(){console.log('Error')});

// Function inside then is resolved
// Function inside catch is rejected