console.log('Children, parent, traversing(Dom)');
// Query selector and getElementBy
/*
With a querySelector statement, you can select an element based on a CSS selector. This means you can select elements by ID, class, or any other type of selector.
Using the getElementById method, you can only select an element by its ID.
query selector mei sab grab kar sakte hai without specifying byclass byid
# for id
. for class
direct name for tag
*/
let cont = document.querySelector('.child');
console.log(cont);
console.log(cont.parentElement);
let bg = document.querySelector('.container');
console.log(bg);
console.log(bg.childNodes);// ==> will show every thing
console.log(bg.children);// ==> will not show comments and unecessary thing
let nodename1= bg.childNodes[3];// ==> <p>...............<p/>
console.log(nodename1);
let nodename2= bg.childNodes[3].nodeName;// ==> P
console.log(nodename2);
let nodename3= bg.childNodes[8].nodeType;// ==> P
console.log(nodename3);
console.log(bg.childNodes[8]);
/*
Node Type
1. element
2. Attribute
3. Text Node
8. Comment
9. document
10. docType
*/

let cont2 = document.querySelector('.container');
console.log(cont2.childNodes);
console.log(cont2.children[1].children[0]);
console.log(cont2.firstChild);
console.log(cont2.firstElementChild);
console.log(cont2.lastChild);
console.log(cont2.lastElementChild);
console.log(cont2.childElementCount);
console.log(cont2.firstElementChild.parentNode);
console.log(cont2.firstElementChild.nextSibling);
console.log(cont2.firstElementChild.nextElementSibling);