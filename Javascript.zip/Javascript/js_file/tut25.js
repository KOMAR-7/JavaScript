console.log('Prototype Inheritance');

const proto = {
    slogan: function () {
        return 'this company is best';
    },
    changeName: function (newName){
        this.name = newName;
    }
}
// this creates Madi Object
let Madi = Object.create(proto);
Madi.name = 'Madi';
Madi.role = 'Programmer';
Madi.changeName('Omar');
console.log(Madi);
// Or (another Syntax)
const Madi1 = Object.create(proto,{
    name: {value: "Madi",writable:true},
    role: {value: "Programmer"}
});
Madi1.changeName('Omar');
console.log(Madi1);

// Prototype inheritance
function Employee(name,salary,experience){
    this.name = name;
    this.salary = salary;
    this.experience = experience;
}
Employee.prototype.slogan = function () {
    return `This company is best. Regards,${this.name}`;
}
// craeting obj
let omarObj = new Employee('Omar',456789,9);
console.log(omarObj);
console.log(omarObj.slogan());

function programmer (name,salary,experience,language){

    Employee.call(this,name,salary,experience);
    this.language  = language;
}
// Inherit prototype
programmer.prototype =Object.create(Employee.prototype)
// Manually set the constructor
programmer.prototype.constructor = programmer

let Rohan = new programmer('Rohan',12332,2,'JavaScript');
console.log(Rohan);

let food = {
    name : this.name,
    make_name : function(name){
        // this.name = name;
        return console.log(`I am making ${name}`);
    },
}
// food.make_name('Cake')
function ingredient(ing1,ing2,water){
        this.ing1 = ing1;
        this.ing2 = ing2;
        this.water = water

}
ingredient.prototype.make = function (){
    return console.log(`I wil be adding ${this.ing1},${this.ing2} and ${this.water}ml of water `);
}
let cakeObj = new ingredient('flour','egg',10);
console.log(cakeObj);
cakeObj.make();

// another
let food1 = {
    change_name: function (food_name){
        this.foodName = food_name
    }
}
let cake = Object.create(food1);
cake.foodName = 'strawberyCake';
cake.price = '234';
cake.unit = '1';
console.log(cake);
/*
Output:
{foodName: 'strawberyCake', price: '234', unit: '1'}
*/

cake.change_name('pineappleCake');
console.log(cake);
/*
Output:
{foodName: 'pineappleCake', price: '234', unit: '1'}
*/
// another
// 1.make constructor
// 2.add prototype
// 3.make another funtion and inherit using call
// 4.add prototype of previous functions to another which inherited using call by child.prototype = Object.create(parent.prototype);
// 5 add it to constructor
function info(name,price,unit){
    this.foodName = name;
    this.price = price;
    this.unit = unit;
}
info.prototype.qua = function (){
    return `${this.foodName} is of best quality at ${this.price}`
}
function make(name,price,unit,total = unit * price){
info.call(this,name,price,unit);
this.total = total;
}
make.prototype = Object.create(info.prototype);
make.prototype.constructor = info;
let cake1 = new make('mango',123,2);
console.log(cake1); 
console.log(cake1.qua());