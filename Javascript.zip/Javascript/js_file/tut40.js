console.log('Regular Expression-Character Sets');
/*
1. Regular Expression
    -Basics Functions
    -Metachracter Symbols
    -Character Sets
*/
// const regex = /^madi/i;
// -Character Set []
// ==> [a-z] any charcter from a to z
// ==> [azos] any charcter from azos
let regex = /M[a-z]di/; // ==> any charcter from a to z
regex = /M[sda]di/; // ==> any charcter from sda
regex = /M[^sdc]di/; // ==> any character except sdc
regex = /M[^sdc]d[^dy]/; // ==> more than one character set
regex = /M[A-Z]di/; // ==> any charcter from A to Z
regex = /M[A-Za-z]d[i-k0-9]/; // ==> any charcter from A to Z or a-z or 0 to 9
// -- Quantifiers (quantity of chracter(specify how many instances of a character))
regex = /Mad{2}i/; // ==> d should occur 2 times for matching
regex = /Mad{0,2}i/ // ==> d should occur 0 to 2 times for matching
regex = /Madi/;
// --Grouping : use parenthesis for grouping
regex = /(Mad){2}/; // ==> const str1 = 'MadMadi is Madi';
regex = /(Mad){2}([0-9]r){3}/ // ==>const str1 = 'MadMad2r4r2r is Madi';



const str1 = 'Madi is Madi';
let result1 = regex.exec(str1);
console.log('The result from exec:', result1);

if (regex.test(str1)) {
    console.log(`The string '${str1}' matches the expression ${regex.source}`);
}
else {
    console.log(`The string '${str1}' does not matches the expression ${regex.source}`);
}