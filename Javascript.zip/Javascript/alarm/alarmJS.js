console.log('Creating an alarm clock');
// var audio = new Audio('Indian Alarm.mp3');
// // audio.play();

// let dt = new Date;
// console.log(dt);
// let stH = 17;
// let stM = 00;
// // console.log(dt.getHours());
// if(dt.getHours === stH && dt.getMinutes === stM){
//     audio.play();
// }
// else{
//     console.log('wait');
// }
const alarmSubmit = document.getElementById('submitBtn');
alarmSubmit.addEventListener('click', setAlarm);

//play alarm ringtone(play audio)
function ringBell() {
    var audio = new Audio('/alarm.mp3');
    audio.play();
}

function setAlarm(e) {
    e.preventDefault();
    const alarm = document.getElementById('alarm');
    alarmDate = new Date(alarm.value)
    if (alarmDate !== NaN) {
        // console.log(alarmDate);
        console.log(`Alarm has been set for ${alarmDate}`);
        now = new Date();
        let timeToAlarm = alarmDate - now;
        console.log(timeToAlarm);
        if (timeToAlarm >= 0) {
            setTimeout(() => {
                console.log('Ringing now');
                ringBell();
            }, timeToAlarm);
            let strTime = document.getElementById('alarmHelp');
            let htmlSmall = `Alarm wiil ring on ${alarmDate}`;
            strTime.innerHTML = htmlSmall;
        }
    }
    else{
        let failure = document.getElementById('failure');
        console.log('Wrong date Format or the time has been passed');
        failure.classList.add('show');
        setTimeout(() => {
            failure.classList.remove('show');
        }, 5000);

    }
}