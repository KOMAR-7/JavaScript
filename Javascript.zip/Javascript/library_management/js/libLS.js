console.log('Libes6 with local storage');
showBook();
let libraryForm = document.getElementById('libraryForm');
libraryForm.addEventListener('submit', addBook);

// add book list
function addBook(e) {

    let nameTxt = document.getElementById('bookName');
    let bname = localStorage.getItem('bname');
    let authorTxt = document.getElementById('author');
    let aname = localStorage.getItem('aname');
    // fiction,programming,cooking
    let fiction = document.getElementById('fiction');
    let programming = document.getElementById('programming');
    let cooking = document.getElementById('cooking');
    let typeTxt;
    if (fiction.checked) {
        typeTxt = fiction;
    }
    else if (programming.checked) {
        typeTxt = programming;
    }
    else if (cooking.checked) {
        typeTxt = cooking;
    }
    let btype = localStorage.getItem('btype');
    if (bname == null && aname == null) {
        bnameObj = [];
        anameObj = [];
        btypeObj = [];
    }
    else {
        bnameObj = JSON.parse(bname);
        anameObj = JSON.parse(aname);
        btypeObj = JSON.parse(btype);
    }
    if (nameTxt.value.length < 2 && authorTxt.value.length < 2) {
        msg('danger', 'Sorry we could not add book');
    }
    else {
        bnameObj.push(nameTxt.value);
        anameObj.push(authorTxt.value);
        btypeObj.push(typeTxt.value);
        localStorage.setItem('bname', JSON.stringify(bnameObj));
        localStorage.setItem('aname', JSON.stringify(anameObj));
        localStorage.setItem('btype', JSON.stringify(btypeObj));
        nameTxt.value = '';
        authorTxt.value = '';
        showBook();
        msg('success', 'Your Book has been successfully added');
    }
    e.preventDefault();
}

//show book list
function showBook() {
    let bname = localStorage.getItem('bname');
    let aname = localStorage.getItem('aname');
    let btype = localStorage.getItem('btype');

    if (bname == null && aname == null) {
        bnameObj = [];
        anameObj = [];
        btypeObj = [];
    }
    else {
        bnameObj = JSON.parse(bname);
        anameObj = JSON.parse(aname);
        btypeObj = JSON.parse(btype);
    }
    let html1 = '';
    let html = '';
    let html2 = '';
    html2 += `
    <div class="containerSrch">
  <form action="" class="search">
    <input class="search__input" type="search" placeholder="Search" id="searchInput">

    <div class="search__icon-container">
      <label for="searchInput" class="search__label" aria-label="Search">
        <svg viewBox="0 0 1000 1000" title="Search"><path fill="currentColor" d="M408 745a337 337 0 1 0 0-674 337 337 0 0 0 0 674zm239-19a396 396 0 0 1-239 80 398 398 0 1 1 319-159l247 248a56 56 0 0 1 0 79 56 56 0 0 1-79 0L647 726z"/></svg>
      </label>

      <button class="search__submit" aria-label="Search">
        <svg viewBox="0 0 1000 1000" title="Search"><path fill="currentColor" d="M408 745a337 337 0 1 0 0-674 337 337 0 0 0 0 674zm239-19a396 396 0 0 1-239 80 398 398 0 1 1 319-159l247 248a56 56 0 0 1 0 79 56 56 0 0 1-79 0L647 726z"/></svg>
      </button>
    </div>
  </form>
</div>
<br>
    `

    bnameObj.forEach(function (element, index) {
        html += `
                <tr class="trClass">
                <td id="td1">${element}</td>
                <td id="td2">${anameObj[index]}</td>
                <td id="td3">${btypeObj[index]}</td>
                <td><button class="button-18" role="button" onclick="deleteBook(this.id)" id="${index}">Delete</button></td>
                </tr>       
        `;
    });
    html1 += `
    
    <br>
    <button class="example_g" type="button" style="margin: auto; display:block; width:80%" onclick="clearLS()">Clear All Books!!!</button>
    <br>
    
    `
    let tableBody = document.getElementById('tableBody');
    let clr = document.getElementById('clr');
    let srch = document.getElementById('srch');
    if (bnameObj.length != 0) {
        tableBody.innerHTML = html;
        clr.innerHTML = html1;
        srch.innerHTML = html2;
    }
    else {
        tableBody.innerHTML = 'Nothing to see here';
    }
}

// clear localStorage
function clearLS() {
    localStorage.clear();
    location.reload();
}

function deleteBook(index) {
    let bname = localStorage.getItem('bname');
    let aname = localStorage.getItem('aname');
    let btype = localStorage.getItem('btype');

    if (bname == null && aname == null) {
        bnameObj = [];
        anameObj = [];
        btypeObj = [];
    }
    else {
        bnameObj = JSON.parse(bname);
        anameObj = JSON.parse(aname);
        btypeObj = JSON.parse(btype);
    }
    bnameObj.splice(index, 1);
    anameObj.splice(index, 1);
    btypeObj.splice(index, 1);
    localStorage.setItem('bname', JSON.stringify(bnameObj));
    localStorage.setItem('aname', JSON.stringify(anameObj));
    localStorage.setItem('btype', JSON.stringify(btypeObj));
    showBook();
    location.reload();
}

function msg(type, msgs) {
    let message = document.getElementById('message');
    message.innerHTML += `
    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
    <strong>Message:</strong> ${msgs}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
`;
    setTimeout(function () {
        message.innerHTML = '';
    }, 3000)
}

// search
let search = document.getElementById('searchInput');
search.addEventListener("input", function () {
    let inputVal = search.value;

    // let inputVal = search.value.toLowerCase();
    // console.log('input event fired');
    // let findSrch = document.getElementByID('tableBody');
    let findSrch = document.getElementsByClassName('trClass');
    Array.from(findSrch).forEach(function (element) {
        let td1 = element.querySelectorAll("#td1")[0].innerText;
        let td2 = element.querySelectorAll("#td2")[0].innerText;
        let td3 = element.querySelectorAll("#td3")[0].innerText;
        if (td1.includes(inputVal) || td2.includes(inputVal) || td3.includes(inputVal)) {
            element.style.display = "table-row";
        }
        else {
            element.style.display = "none";
        }

        // console.log(cardTxt);
    })
})


