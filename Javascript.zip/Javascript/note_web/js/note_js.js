console.log('Note_web');
 // ==>on load it should check the local storage and print
// if user adds a note add it to a local storage
// let inputValNote;
// let inputValTitle; 
// let chkTitle = document.getElementById('noteTitle');
// chkTitle.addEventListener("input",function(){
//     inputValTitle = chkTitle.value;
// })
// let chkNote = document.getElementById('addTxt');
// chkNote.addEventListener("input",function(){
//     inputValNote = chkNote.value;
// })
// if(inputValTitle<=1 && inputValNote<=1){
showNotes();
let addBtn = document.getElementById('addBtn');
addBtn.addEventListener('click', function (e) {

    let addTxt = document.getElementById('addTxt');// ==>textarea note
    let notes = localStorage.getItem('notes');
    let titleTxt = document.getElementById('noteTitle'); // ==>textarea title
    let title = localStorage.getItem('title');

    if (notes == null && title == null) {
        notesObj = [];
        titleObj = [];
    } else {
        notesObj = JSON.parse(notes);// ==>converting string into array
        titleObj = JSON.parse(title);
    }
    notesObj.push(addTxt.value);
    titleObj.push(titleTxt.value);
    localStorage.setItem('notes', JSON.stringify(notesObj));
    localStorage.setItem('title',JSON.stringify(titleObj))
    addTxt.value = '';
    titleTxt.value = '';
    // console.log(localStorage.getItem('notes'));
    // till here you'll get all the note together in form of array;
    showNotes();
})

// function ot show elements from localStorage
function showNotes() {
    let notes = localStorage.getItem('notes');
    // let titleTxt = document.getElementById('noteTitle');
    let title = localStorage.getItem('title');

    if (notes == null && title == null) {
        notesObj = [];
        titleObj = [];
    } else {
        notesObj = JSON.parse(notes);// ==>converting string into array
        titleObj = JSON.parse(title);
    }
    
    let html = "";
    html+=`
    <br>
    <br>
    <button class="example_g" type="button" style="margin: auto; display:block; width:80%" onclick="clearLS()">Clear All Notes!!!</button>
    <br>
    <br>
    <br>
    `
    notesObj.forEach(function(element, index) {
        html += `
        <div class="noteCards card my-2 mx-2" style="width: 18rem;">
            <div class="card-body">
                <h5 id="titleHeading" class="card-title">${titleObj[index]} (${index+1})</h5>
                <p class="card-text">${element}</p>
                <button id="${index}" onclick="deleteNote(this.id)" class="btn btn-primary">Delete Note</button>
                </div>
        </div>`;
});
// this refers to current id
let notesElem = document.getElementById('notes');
if (notesObj.length !=0) {
    notesElem.innerHTML=html;
}
else{
    notesElem.innerHTML=`Nothing to see here. Use 'add notes' to add a note`
}

}

// function to delete a note
function deleteNote(index){
    // console.log('I am deleting ',index);
    let notes = localStorage.getItem('notes');
    let titleTxt = document.getElementById('noteTitle');
    let title = localStorage.getItem('title');
    if (notes == null && title == null) {
        notesObj = [];
        titleObj = [];
    } else {
        notesObj = JSON.parse(notes);// ==>converting string into array
        titleObj = JSON.parse(title);
    }
    notesObj.splice(index,1); // //==>takes the first argument and deletes upto specified index
    titleObj.splice(index,1);
    localStorage.setItem('notes', JSON.stringify(notesObj));
    localStorage.setItem('title', JSON.stringify(titleObj));

    showNotes();
}

let search = document.getElementById('searchTxt');
search.addEventListener("input",function(){
    let inputVal = search.value.toLowerCase();

    // let inputVal = search.value.toLowerCase();
    // console.log('input event fired');
    let noteCards = document.getElementsByClassName('noteCards');
    Array.from(noteCards).forEach(function(element){
        let titleTxt = element.getElementsByTagName("h5")[0].innerText;
        let cardTxt = element.getElementsByTagName("p")[0].innerText;
        // let titleTxt = element.getElementById('titleHeading')[0].innerText;
        if(cardTxt.includes(inputVal) || titleTxt.includes(inputVal)){
            element.style.display = "block";
        }
        else{
            element.style.display = "none";
        }
    
        // console.log(cardTxt);
    })
})

// else{
//     alert("Empty");
// }
// clear localstorage
function clearLS(){
    localStorage.clear();
    location.reload();
}

    // <input type="submit" onclick="clearLS()" class="btn btn-primary" style="margin: auto; display:block" id="clearBtn" value="Clear All Notes">
    // Style Script for add note butoon
    var animateButton = function(e) {

        e.preventDefault;
        //reset animation
        e.target.classList.remove('animate');
        
        e.target.classList.add('animate');
        setTimeout(function(){
          e.target.classList.remove('animate');
        },700);
      };
      
      var bubblyButtons = document.getElementsByClassName("bubbly-button");
      
      for (var i = 0; i < bubblyButtons.length; i++) {
        bubblyButtons[i].addEventListener('click', animateButton, false);
      }